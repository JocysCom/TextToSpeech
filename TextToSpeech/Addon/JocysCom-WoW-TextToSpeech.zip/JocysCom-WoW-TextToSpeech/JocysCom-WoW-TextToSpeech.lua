-- /fstack - show frame names

-- DEFAULT VOICES

Female = "IVONA 2 Amy";
Male = "IVONA 2 Brian";
Unknown = "Microsoft Zira Desktop";

PitchMin = "-10";
PitchMax = "10";

RateMin = "-5";
RateMax = "5";

local defaultSettings =
{
	{
		["Gender"] = "Female",
		["EditBoxPrefix"] = "EditBoxF",
		["TopLeft"] = 8,
		["Voices"] =
		{
			{ true, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
			{ false, 100, "IVONA 2 Amy" },
		},
	},
	{
		["Gender"] = "Male",
		["EditBoxPrefix"] = "EditBoxM",
		["TopLeft"] = (8 + 160),
		["Voices"] =
		{
			{ true, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
			{ false, 100, "IVONA 2 Brian" },
		},
	},
	{
		["Gender"] = "Neutral",
		["EditBoxPrefix"] = "EditBoxU",
		["TopLeft"] = (8 + 320),
		["Voices"] =
		{
			{ true, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
			{ false, 100, "Microsoft Zira Desktop" },
		},
	},
};

-- TEXT

unitName = UnitName("player");
messageStop = "<voice command=\"stop\" />";

textFrameOptionsTitle = "JOCYS.COM WORLD OF WARCRAFT TEXT TO SPEECH ADDON - VERSION 2014.08.25";
textDescription = "How it works: When you open NPC dialogue window, |cff77ccffJocys.Com WoW Text to Speech Addon|r creates and sends special whisper message to yourself (message includes dialogue text, voice name, pitch value and effect name). Then, |cff77ccffJocys.Com WoW Text to Speech Monitor|r (which must be running in background) picks-up this message from your network traffic and reads it with text-to-speech voice. You can use free text-to-speech voices by Microsoft or you can download and install additional and better text-to-speech voices from |cff77ccffIvona.com|r website. Good voices are English-British \"Amy\" and \"Brian\". English-American \"Salli\" and \"Joey\" are not bad too. For more help and to download or update |cff77ccffAddon|r with |cff77ccffMonitor|r, visit \"Software\" section of |cff77ccffJocys.com|r website.";
textReplace = "CHANGE MY NAME IN TTS\n\n FROM |cff00ff00" .. unitName .. "|r TO";
textPitch = "Minimum ... PITCH ... Maximum\n\nRecommended: from " .. PitchMin .. " to " .. PitchMax;
textRate = "Minimum ... RATE ... Maximum\n\nRecommended: from " .. RateMin .. " to " .. RateMax;
textDefaults = "RESET and FILL FIELDS with DEFAULT VALUES";
textFrameScroll = "When addon is enabled and quest window is open, you can use your mouse wheel over this frame.\n\nSCROLL UP = START SPEECH\n\nSCROLL DOWN = STOP SPEECH";
textDoNotDisturb = "Please wait... NPC dialog window is open and text-to-speech is enabled.";

-- FUNCTION SET COLOR
local function GetFrame(frameName)
	local frame = EnumerateFrames();
	-- Get the first frame
	while frame do
		if frame:GetName() == frameName then
			return frame;
		end
		frame = EnumerateFrames(frame);
		-- Get the next frame
	end
end

-- FUNCTION : CREATE DEFAULT FRAME

local function createFrame(name, parent)
	frame = CreateFrame("Frame", name, parent);
	frame:Hide();
	frame:SetSize(100, 100);
	frame:SetFrameStrata("HIGH");
	frame:SetMovable(true);
	frame:EnableMouse(true);
	frame:RegisterForDrag("LeftButton");
	frame:SetScript("OnDragStart", frame.StartMoving);
	frame:SetScript("OnDragStop", frame.StopMovingOrSizing);
	frame.texture = frame:CreateTexture("ARTWORK");
	frame.texture:SetAllPoints();
	frame.texture:SetTexture(0, 0, 0, 0.8);
end

-- FUNCTION : CREATE DEFAULT EDITBOX

local function createEditBox(name, parent, text, width)
	if width == nil then
		width = 100;
	end
	frame = CreateFrame("EditBox", name, parent);
	frame:SetSize(width, 15);
	frame:SetTextInsets(2, 2, 0, 0);
	frame:SetFontObject("GameFontHighlightSmall");
	frame:SetText(text);
	frame.texture = frame:CreateTexture("ARTWORK");
	frame.texture:SetAllPoints();
	frame.texture:SetTexture(0, 0, 0, 1.0);
	return frame;
end

-- FUNCTION : CREATE DEFAULT EDITBOX 2

local function createEditBox2(name, parent, text)
	frame = CreateFrame("EditBox", name, parent);
	frame:SetSize(80, 15);
	frame:SetTextInsets(2, 2, 0, 0);
	frame:SetFontObject("GameFontHighlightSmall");
	frame:SetText(text);
	frame.texture = frame:CreateTexture("ARTWORK");
	frame.texture:SetAllPoints();
	frame.texture:SetTexture(0, 0, 0, 1.0);
	frame:SetJustifyH("CENTER");
	return frame;
end

-- FUNCTION : CREATE DEFAULT EDITBOX 2

local crcTable = {
	0x00000000,0x77073096,0xee0e612c,0x990951ba,0x076dc419,0x706af48f,0xe963a535,0x9e6495a3,
	0x0edb8832,0x79dcb8a4,0xe0d5e91e,0x97d2d988,0x09b64c2b,0x7eb17cbd,0xe7b82d07,0x90bf1d91,
	0x1db71064,0x6ab020f2,0xf3b97148,0x84be41de,0x1adad47d,0x6ddde4eb,0xf4d4b551,0x83d385c7,
	0x136c9856,0x646ba8c0,0xfd62f97a,0x8a65c9ec,0x14015c4f,0x63066cd9,0xfa0f3d63,0x8d080df5,
	0x3b6e20c8,0x4c69105e,0xd56041e4,0xa2677172,0x3c03e4d1,0x4b04d447,0xd20d85fd,0xa50ab56b,
	0x35b5a8fa,0x42b2986c,0xdbbbc9d6,0xacbcf940,0x32d86ce3,0x45df5c75,0xdcd60dcf,0xabd13d59,
	0x26d930ac,0x51de003a,0xc8d75180,0xbfd06116,0x21b4f4b5,0x56b3c423,0xcfba9599,0xb8bda50f,
	0x2802b89e,0x5f058808,0xc60cd9b2,0xb10be924,0x2f6f7c87,0x58684c11,0xc1611dab,0xb6662d3d,
	0x76dc4190,0x01db7106,0x98d220bc,0xefd5102a,0x71b18589,0x06b6b51f,0x9fbfe4a5,0xe8b8d433,
	0x7807c9a2,0x0f00f934,0x9609a88e,0xe10e9818,0x7f6a0dbb,0x086d3d2d,0x91646c97,0xe6635c01,
	0x6b6b51f4,0x1c6c6162,0x856530d8,0xf262004e,0x6c0695ed,0x1b01a57b,0x8208f4c1,0xf50fc457,
	0x65b0d9c6,0x12b7e950,0x8bbeb8ea,0xfcb9887c,0x62dd1ddf,0x15da2d49,0x8cd37cf3,0xfbd44c65,
	0x4db26158,0x3ab551ce,0xa3bc0074,0xd4bb30e2,0x4adfa541,0x3dd895d7,0xa4d1c46d,0xd3d6f4fb,
	0x4369e96a,0x346ed9fc,0xad678846,0xda60b8d0,0x44042d73,0x33031de5,0xaa0a4c5f,0xdd0d7cc9,
	0x5005713c,0x270241aa,0xbe0b1010,0xc90c2086,0x5768b525,0x206f85b3,0xb966d409,0xce61e49f,
	0x5edef90e,0x29d9c998,0xb0d09822,0xc7d7a8b4,0x59b33d17,0x2eb40d81,0xb7bd5c3b,0xc0ba6cad,
	0xedb88320,0x9abfb3b6,0x03b6e20c,0x74b1d29a,0xead54739,0x9dd277af,0x04db2615,0x73dc1683,
	0xe3630b12,0x94643b84,0x0d6d6a3e,0x7a6a5aa8,0xe40ecf0b,0x9309ff9d,0x0a00ae27,0x7d079eb1,
	0xf00f9344,0x8708a3d2,0x1e01f268,0x6906c2fe,0xf762575d,0x806567cb,0x196c3671,0x6e6b06e7,
	0xfed41b76,0x89d32be0,0x10da7a5a,0x67dd4acc,0xf9b9df6f,0x8ebeeff9,0x17b7be43,0x60b08ed5,
	0xd6d6a3e8,0xa1d1937e,0x38d8c2c4,0x4fdff252,0xd1bb67f1,0xa6bc5767,0x3fb506dd,0x48b2364b,
	0xd80d2bda,0xaf0a1b4c,0x36034af6,0x41047a60,0xdf60efc3,0xa867df55,0x316e8eef,0x4669be79,
	0xcb61b38c,0xbc66831a,0x256fd2a0,0x5268e236,0xcc0c7795,0xbb0b4703,0x220216b9,0x5505262f,
	0xc5ba3bbe,0xb2bd0b28,0x2bb45a92,0x5cb36a04,0xc2d7ffa7,0xb5d0cf31,0x2cd99e8b,0x5bdeae1d,
	0x9b64c2b0,0xec63f226,0x756aa39c,0x026d930a,0x9c0906a9,0xeb0e363f,0x72076785,0x05005713,
	0x95bf4a82,0xe2b87a14,0x7bb12bae,0x0cb61b38,0x92d28e9b,0xe5d5be0d,0x7cdcefb7,0x0bdbdf21,
	0x86d3d2d4,0xf1d4e242,0x68ddb3f8,0x1fda836e,0x81be16cd,0xf6b9265b,0x6fb077e1,0x18b74777,
	0x88085ae6,0xff0f6a70,0x66063bca,0x11010b5c,0x8f659eff,0xf862ae69,0x616bffd3,0x166ccf45,
	0xa00ae278,0xd70dd2ee,0x4e048354,0x3903b3c2,0xa7672661,0xd06016f7,0x4969474d,0x3e6e77db,
	0xaed16a4a,0xd9d65adc,0x40df0b66,0x37d83bf0,0xa9bcae53,0xdebb9ec5,0x47b2cf7f,0x30b5ffe9,
	0xbdbdf21c,0xcabac28a,0x53b39330,0x24b4a3a6,0xbad03605,0xcdd70693,0x54de5729,0x23d967bf,
	0xb3667a2e,0xc4614ab8,0x5d681b02,0x2a6f2b94,0xb40bbe37,0xc30c8ea1,0x5a05df1b,0x2d02ef8d
};

local function ComputeHashCrc32(crc32, buffer, offset, length)
	crc32 = bit.bxor(crc32, 0xFFFFFFFF);
	while length > 0 do
		length = length - 1;
		crc32 = bit.bxor(crcTable[bit.band(bit.bxor(crc32, buffer[offset]), 0xFF) + 1], bit.rshift(crc32, 8));
		offset = offset + 1;
	end
	crc32 = bit.bxor(crc32, 0xFFFFFFFF);
	return crc32;
end

local function ComputeHash(s)
	local buffer = { };
	local len = string.len(s)
	for i = 1, len do
		buffer[i - 1] = string.byte(s, i);
	end
	return ComputeHashCrc32(0, buffer, 0, len);
end

local function GetNumber(min, max, key, value)
	local s = key .. value;
	local hash = ComputeHash(s);
	local d = bit.band((max - min), 0xFFFFFFFF);
	if d == 0xFFFFFFFF then
		return hash;
	end
	return min +(hash %(d + 1));
end

local function PickVoice(voices, s)
	local count = 0;
	local len = table.getn(voices);
	local min = 0;
	local max = 0;
	for i = 1, len, 1 do
		max = max + voices[i][2];
	end
	local number = GetNumber(0,(max - 1), "voice", s);
	local name = "";
	local weight;
	local currentWeight = 0;
	for i = 1, len, 1 do
		name = voices[i][1];
		weight = voices[i][2];
		if number <(currentWeight + weight) then
			return name;
		end
		currentWeight = currentWeight + weight;
	end
	return name;
end

-- MINI FRAME

createFrame("FrameMini", UIParent);
frame:SetFrameStrata("DIALOG");
FrameMini:SetSize(106, 20);
FrameMini:SetPoint("TOPLEFT", 245, -147);
FrameMini.texture:SetTexture(0, 0, 0, 0);

-- MINI FRAME EDITBOX

createEditBox("EditBoxMini", FrameMini, "");
EditBoxMini:SetPoint("TOPLEFT", 0, 0);
EditBoxMini:SetSize(0, 15);

-- MINI FRAME OPTIONS BUTTON

CreateFrame("Button", "ButtonOptions", FrameMini, "UIPanelButtonTemplate");
ButtonOptions:SetPoint("TOPLEFT", 8, 1);
ButtonOptions:SetSize(90, 21);
ButtonOptions:SetText("Options");

-- OPTIONS FRAME

--CreateFrame("Frame", "FrameOptions", UIParent, "BasicFrameTemplate");
--FrameOptions:Hide();
--FrameOptions:SetSize(716, 496);
--FrameOptions:SetPoint("TOPLEFT", 356, -116);
--FrameOptions:SetFrameStrata("HIGH");
--FrameOptions:SetMovable(true);
--FrameOptions:EnableMouse(true);
--FrameOptions:RegisterForDrag("LeftButton");
--FrameOptions:SetScript("OnDragStart", frame.StartMoving);
--FrameOptions:SetScript("OnDragStop", frame.StopMovingOrSizing);

-- OPTIONS FRAME TITLE

--FrameOptions:CreateFontString("TitleOptions", ARTWORK, "GameFontHighlightSmall");
--TitleOptions:SetPoint("TOP", -9, -7);
--TitleOptions:SetTextColor(1.0, 0.8, 0.0, 1.0);
--TitleOptions:SetText(textFrameOptionsTitle);

-- OPTIONS FRAME EVENTS

--FrameOptions:RegisterEvent("ADDON_LOADED");
--FrameOptions:RegisterEvent("QUEST_GREETING");
--FrameOptions:RegisterEvent("GOSSIP_SHOW");
--FrameOptions:RegisterEvent("QUEST_DETAIL");
--FrameOptions:RegisterEvent("QUEST_PROGRESS");
--FrameOptions:RegisterEvent("QUEST_COMPLETE");
--FrameOptions:RegisterEvent("QUEST_ACCEPTED");
--FrameOptions:RegisterEvent("QUEST_FINISHED");
--FrameOptions:RegisterEvent("GOSSIP_CLOSED");
--FrameOptions:RegisterEvent("PLAYER_LOGOUT");

-- ENABLE/DISABLE ADDON CHECKBUTTON

--CreateFrame("CheckButton", "CheckButtonEnable", FrameOptions, "UICheckButtonTemplate");
--CheckButtonEnable:SetPoint("TOPLEFT", 7, -25);
--CheckButtonEnable:SetChecked(1);

-- ENABLE/DISABLE ADDON CHECKBUTTON TITLE

--CheckButtonEnable:CreateFontString("CheckButtonEnableTitle", ARTWORK, "GameFontHighlightSmall");
--CheckButtonEnableTitle:SetPoint("LEFT", 35, 0);
--CheckButtonEnableTitle:SetText("Enable addon");
--CheckButtonEnableTitle:SetTextColor(0.5, 0.5, 0.5, 1.0);

-- ENABLE/DISABLE AUTO START SPEECH CHECKBUTTON

CreateFrame("CheckButton", "CheckButtonAuto", FrameOptions, "UICheckButtonTemplate");
CheckButtonAuto:SetPoint("TOPLEFT", 115, -25);
CheckButtonAuto:SetChecked(1);

-- ENABLE/DISABLE AUTO START SPEECH CHECKBUTTON TITLE

CheckButtonAuto:CreateFontString("CheckButtonAutoTitle", ARTWORK, "GameFontHighlightSmall");
CheckButtonAutoTitle:SetPoint("LEFT", 34, 0);
CheckButtonAutoTitle:SetText("Auto start speech when dialog window is open");
CheckButtonAutoTitle:SetTextColor(0.5, 0.5, 0.5, 1.0);

-- ENABLE/DISABLE AUTO DO NOT DISTURB CHECKBUTTON

CreateFrame("CheckButton", "CheckButtonDND", FrameOptions, "UICheckButtonTemplate");
CheckButtonDND:SetPoint("TOPLEFT", 393, -25); -- 74
CheckButtonDND:SetChecked(1);

-- ENABLE/DISABLE AUTO DO NOT DISTURB CHECKBUTTON TITLE

CheckButtonDND:CreateFontString("CheckButtonDNDTitle", ARTWORK, "GameFontHighlightSmall");
CheckButtonDNDTitle:SetPoint("LEFT", 35, 0);
CheckButtonDNDTitle:SetText("Auto \"Do not disturb\"");
CheckButtonDNDTitle:SetTextColor(0.5, 0.5, 0.5, 1.0);

-- ENABLE/DISABLE MESSAGE FILTER CHECKBUTTON

CreateFrame("CheckButton", "CheckButtonFilter", FrameOptions, "UICheckButtonTemplate");
CheckButtonFilter:SetPoint("TOPLEFT", 546, -25);
CheckButtonFilter:SetChecked(1);

-- ENABLE/DISABLE MESSAGE FILTER CHECKBUTTON TITLE

CheckButtonFilter:CreateFontString("CheckButtonFilterTitle", ARTWORK, "GameFontHighlightSmall");
CheckButtonFilterTitle:SetPoint("LEFT", 35, 0);
CheckButtonFilterTitle:SetText("Hide addon messages");
CheckButtonFilterTitle:SetTextColor(0.5, 0.5, 0.5, 1.0);

-- FUNCTION : ENABLE MESSAGE FILTER : CHAT_MSG_WHISPER_INFORM

local function hideMessageInform(self, event, msg)
	if msg:find("<voice") then
		return true;
	end
end
ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER_INFORM", hideMessageInform);

-- FUNCTION : ENABLE/DISABLE MESSAGE FILTER : CHAT_MSG_WHISPER

local function hideMessage(self, event, msg)
	if msg:find("<voice") and CheckButtonFilter:GetChecked() == 1 then
		return true;
	end
end

-- FUNCTION : ENABLE/DISABLE MESSAGE FILTER : CHAT_MSG_DND

local function hideMessageDND(self, event, msg)
	if msg:find("<" .. unitName .. ">: ") and CheckButtonFilter:GetChecked() == 1 then
		return true;
	end
end

-- FUNCTION : ENABLE/DISABLE MESSAGE FILTER : CHAT_MSG_SYSTEM

local function hideMessageSYSTEM(self, event, msg)
	if msg:find("You are no") and CheckButtonFilter:GetChecked() == 1 then
		return true;
	end
end

-- FUNCTION : ENABLE/DISABLE MESSAGE FILTER

local function functionFilter()
	ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", hideMessage);
	ChatFrame_AddMessageEventFilter("CHAT_MSG_DND", hideMessageDND);
	ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", hideMessageSYSTEM);
end

functionFilter();
CheckButtonFilter:SetScript("OnClick", functionFilter);

-- MOUSE SCROLL FRAME

createFrame("FrameScroll", UIParent);
frame:SetFrameStrata("DIALOG");
FrameScroll.texture:SetTexture(0, 0, 0, 0);
FrameScroll:SetPoint("TOPLEFT", 33, -188);
FrameScroll:SetSize(278, 200);

-- MOUSE SCROLL FRAME DESCRIPTION

FrameScroll:CreateFontString("TextScroll", ARTWORK, "GameFontHighlightSmall");
TextScroll:Hide();
TextScroll:SetPoint("CENTER");
TextScroll:SetSize(200, 200);
TextScroll:SetJustifyH("CENTER");
TextScroll:SetJustifyV("CENTER");
TextScroll:SetTextColor(0.5, 0.5, 0.5, 1.0);
TextScroll:SetText(textFrameScroll);

-- MOUSE SCROLL FRAME RESIZE BUTTON

CreateFrame("Button", "ResizeButton", FrameScroll);
ResizeButton:Hide();
ResizeButton:SetPoint("BOTTOMRIGHT");
ResizeButton:SetSize(16, 16);
ResizeButton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up");
ResizeButton:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight");
ResizeButton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down");

-- FUNCTIONS : MOUSE SCROLL FRAME RESIZE

local function resizeStart()
	FrameScroll:StartSizing("BOTTOMRIGHT");
	FrameScroll:SetUserPlaced(true);
end

ResizeButton:SetScript("OnMouseDown", resizeStart);

local function resizeStop()
	FrameScroll:StopMovingOrSizing();
end

ResizeButton:SetScript("OnMouseUp", resizeStop);

-- QUEST FRAME

CreateFrame("Frame", "FrameQuest", FrameOptions, "InsetFrameTemplate");
FrameQuest:SetPoint("BOTTOMLEFT", 4, 346);
FrameQuest:SetSize(708, 91);

-- QUEST FRAME BLACK BACKROUND

CreateFrame("Frame", "FrameQuestBackground", FrameQuest);
FrameQuestBackground:SetSize(700, 83);
FrameQuestBackground:SetPoint("TOPLEFT", 4, -4);
FrameQuestBackground.texture = FrameQuestBackground:CreateTexture("ARTWORK");
FrameQuestBackground.texture:SetAllPoints();
FrameQuestBackground.texture:SetTexture(0, 0, 0, 1.0);

-- QUEST EDITBOX

createEditBox("EditBoxQuest", FrameQuest, "");
EditBoxQuest:SetPoint("TOPLEFT", 0, 140);
EditBoxQuest:SetWidth(682);
EditBoxQuest:SetMultiLine();
EditBoxQuest:SetTextInsets(5, 5, 5, 5);
EditBoxQuest:SetTextColor(0.5, 0.5, 0.5, 1.0);
EditBoxQuest.texture:SetTexture(0, 0, 0, 0.0);

-- QUEST SCROLLFRAME

CreateFrame("ScrollFrame", "ScrollFrameQuest", FrameQuest, "UIPanelScrollFrameTemplate");
ScrollFrameQuest:SetPoint("TOPLEFT", 5, -5);
ScrollFrameQuest:SetPoint("BOTTOMRIGHT", -26, 3);
ScrollFrameQuest:SetScrollChild(EditBoxQuest);

-- VOICES FRAME

CreateFrame("Frame", "FrameVoices", FrameOptions, "InsetFrameTemplate");
FrameVoices:SetPoint("BOTTOMLEFT", 4, 108);
FrameVoices:SetSize(496, 237);

-- VOICE EDITBOXES AND TITLE 

local function CreateFrames(prefix, gender, voices, position)
	local voicesLen = table.getn(voices) -1;
	for i = 0, voicesLen do
		local name = prefix .. i;
		local enabled = voices[i + 1][1];
		local weight = voices[i + 1][2];
		local voice = voices[i + 1][3];
		local top = -24 -(i * 24);
		local item;
		-- Create CheckButton
		CreateFrame("CheckButton", name .. "Check", FrameVoices, "UICheckButtonTemplate");
		item = GetFrame(name .. "Check");
		item:SetPoint("TOPLEFT", position, top);
		item:SetChecked(enabled);
		-- Create weight TextBox.
		createEditBox(name .. "Weight", FrameVoices, weight, 32);
		item = GetFrame(name .. "Weight");
		item:SetPoint("TOPLEFT", position + 32, top - 9);
		item:SetJustifyH("RIGHT");
		-- Create voice name TextBox.
		createEditBox(name, FrameVoices, voice, 90);
		item = GetFrame(name);
		item:SetPoint("TOPLEFT", position + 32 + 32 + 4, top - 9);
		if i == 0 then
			local titleName = "Title" .. gender;
			local titleText = string.upper(gender) .. " TTS VOICES";
			local fontString = item:CreateFontString(titleName, ARTWORK, "GameFontHighlightSmall");
			fontString:SetPoint("TOPLEFT", -34, 21);
			fontString:SetTextColor(0.5, 0.5, 0.5, 1.0);
			fontString:SetText(titleText);
		end
	end
end

local len = table.getn(defaultSettings);
for i = 1, len do
	local row = defaultSettings[i];
	local gender = row["Gender"];
	local editBoxPrefix = row["EditBoxPrefix"];
	local topLeft = row["TopLeft"];
	local voices = row["Voices"];
	local voicesLen = table.getn(voices);
	-- createEditBox("TestEditBox", FrameVoices, voicesLen);
	-- GetFrame("TestEditBox"):SetPoint("BOTTOMRIGHT", -353, 192);
	CreateFrames(editBoxPrefix, gender, voices, topLeft);
end

-- DESCRIPTION FRAME

CreateFrame("Frame", "FrameDescription", FrameOptions, "InsetFrameTemplate");
FrameDescription:SetPoint("BOTTOMLEFT", 4, 27);
FrameDescription:SetSize(708, 80);

-- DESCRIPTION TEXT

FrameDescription:CreateFontString("textDesription", ARTWORK, "GameFontHighlightSmall");
textDesription:SetPoint("TOPLEFT", 10, -9);
textDesription:SetSize(690, 420);
textDesription:SetJustifyH("LEFT");
textDesription:SetJustifyV("TOP");
textDesription:SetTextColor(0.5, 0.5, 0.5, 1.0);
textDesription:SetText(textDescription);

-- NAME FRAME

CreateFrame("Frame", "FrameName", FrameOptions, "InsetFrameTemplate");
FrameName:SetPoint("BOTTOMRIGHT", -4, 266);
FrameName:SetSize(212, 79);

-- NAME TITLE

FrameName:CreateFontString("TitleReplaceName", ARTWORK, "GameFontHighlightSmall");
TitleReplaceName:SetPoint("TOP", 0, -12);
TitleReplaceName:SetTextColor(0.5, 0.5, 0.5, 1.0);
TitleReplaceName:SetText(textReplace);

-- NAME EDITBOX

createEditBox("EditBoxReplaceName", FrameName, unitName);
EditBoxReplaceName:SetPoint("BOTTOM", 0, 12);
EditBoxReplaceName:SetJustifyH("CENTER");
EditBoxReplaceName:SetSize(186, 15);

-- PITCH FRAME

CreateFrame("Frame", "FramePitch", FrameOptions, "InsetFrameTemplate");
FramePitch:SetPoint("BOTTOMRIGHT", -4, 187);
FramePitch:SetSize(212, 78);

-- PITCH TITLE

FramePitch:CreateFontString("TitlePitch", ARTWORK, "GameFontHighlightSmall");
TitlePitch:SetPoint("TOP", 9, -12);
TitlePitch:SetTextColor(0.5, 0.5, 0.5, 1.0);
TitlePitch:SetText(textPitch);

-- PITCH POSITIVE EDITBOXES

createEditBox2("EditBoxPitchMin", FramePitch, PitchMin); EditBoxPitchMin:SetPoint("BOTTOMRIGHT", -103, 12);
createEditBox2("EditBoxPitchMax", FramePitch, PitchMax); EditBoxPitchMax:SetPoint("BOTTOMRIGHT", -13, 12);

-- RATE FRAME

CreateFrame("Frame", "FrameRate", FrameOptions, "InsetFrameTemplate");
FrameRate:SetPoint("BOTTOMRIGHT", -4, 108);
FrameRate:SetSize(212, 78);

-- RATE TITLE

FrameRate:CreateFontString("TitleRate", ARTWORK, "GameFontHighlightSmall");
TitleRate:SetPoint("TOP", 9, -12);
TitleRate:SetTextColor(0.5, 0.5, 0.5, 1.0);
TitleRate:SetText(textRate);

-- RATE EDITBOX

createEditBox2("EditBoxRateMin", FrameRate, RateMin); EditBoxRateMin:SetPoint("BOTTOMRIGHT", -103, 12);
createEditBox2("EditBoxRateMax", FrameRate, RateMax); EditBoxRateMax:SetPoint("BOTTOMRIGHT", -13, 12);


-- DEFAULTS BUTTON

CreateFrame("Button", "ButtonDefault", FrameOptions, "UIPanelButtonTemplate");
ButtonDefault:SetPoint("BOTTOMRIGHT", -4, 4);
ButtonDefault:SetText(textDefaults);
ButtonDefault:SetWidth(303);

-- FUNCTION : RESET / DEFAULT VALUES

local function defaultFunction()
	local len = table.getn(defaultSettings);
	for i = 1, len do
		local row = defaultSettings[i];
		local editBoxPrefix = row["EditBoxPrefix"];
		local voices = row["Voices"];
		local voicesLen = table.getn(voices);
		for v = 1, voicesLen do
			local voice = voices[v][3];
			GetFrame(editBoxPrefix ..(v - 1)).SetText(voice);
		end
	end
	EditBoxRateMin:SetText(RateMin);
	EditBoxRateMax:SetText(RateMax);
	EditBoxPitchMin:SetText(PitchMin);
	EditBoxPitchMax:SetText(PitchMax);
	EditBoxReplaceName:SetText(unitName);

end
ButtonDefault:SetScript("OnClick", defaultFunction);

-- FUNCTIONS FOR ALL EVENTS
local function eventFunction(self, event)

	-- FUNCTION ON ADDON_LOADED

	if event == "ADDON_LOADED" then
		if CheckButtonEnableValue ~= 1 then CheckButtonEnableValue = nil end;
		CheckButtonEnable:SetChecked(CheckButtonEnableValue);
		if CheckButtonAutoValue ~= 1 then CheckButtonAutoValue = nil end;
		CheckButtonAuto:SetChecked(CheckButtonAutoValue);
		if CheckButtonDNDValue ~= 1 then CheckButtonDNDValue = nil end;
		CheckButtonDND:SetChecked(CheckButtonDNDValue);
		if CheckButtonFilterValue ~= 1 then CheckButtonFilterValue = nil end;
		CheckButtonFilter:SetChecked(CheckButtonFilterValue);
		if CharacterFirstLoginValue ~= 1 then
			CheckButtonEnable:SetChecked(1);
			CheckButtonAuto:SetChecked(1);
			CheckButtonDND:SetChecked(1);
			CheckButtonFilter:SetChecked(1);
		end
		if EditBoxReplaceNameValue == "" or EditBoxReplaceNameValue == nil then EditBoxReplaceNameValue = unitName end;
		EditBoxReplaceName:SetText(EditBoxReplaceNameValue);
		if EditBoxRateMin == "" or EditBoxRateMinValue == nil then EditBoxRateMinValue = RateMin end;
		EditBoxRateMin:SetText(EditBoxRateMinValue);
		if EditBoxRateMax == "" or EditBoxRateMaxValue == nil then EditBoxRateMaxValue = RateMax end;
		EditBoxRateMax:SetText(EditBoxRateMaxValue);
		if EditBoxPitchMin == "" or EditBoxPitchMinValue == nil then EditBoxPitchMinValue = PitchMin end;
		EditBoxPitchMin:SetText(EditBoxPitchMinValue);
		if EditBoxPitchMax == "" or EditBoxPitchMaxValue == nil then EditBoxPitchMaxValue = PitchMax end;
		EditBoxPitchMax:SetText(EditBoxPitchMaxValue);
		local len = table.getn(defaultSettings);
		for i = 1, len do
			local row = defaultSettings[i];
			local editBoxPrefix = row["EditBoxPrefix"];
			local voices = row["Voices"];
			local voicesLen = table.getn(voices);
			for v = 1, voicesLen do
				-- Get default value
				local voice = voices[v][3];
				if AllSavedValues ~= nil then
					if AllSavedValues[i] ~= nil then
						if AllSavedValues[i]["Voices"] ~= nil then
							if AllSavedValues[i]["Voices"][v] ~= nil then
								if AllSavedValues[i]["Voices"][v][3] ~= nil then
									voice = AllSavedValues[i]["Voices"][v][3];
								end
							end
						end
					end
				end
				local name = editBoxPrefix ..(v - 1);
				GetFrame(name):SetText(voice);
			end
		end
		FrameMini:SetMovable(true);
		FrameMini:SetUserPlaced(true);
		FrameOptions:SetMovable(true);
		FrameOptions:SetUserPlaced(true);
		FrameScroll:SetMovable(true);
		FrameScroll:SetResizable(true);
		FrameScroll:SetUserPlaced(true);
	end


	-- FUNCTION SAVE VALUES (ON OPTIONS CLOSE AND LOGOUT)
	function saveValues()
		CheckButtonEnableValue = CheckButtonEnable:GetChecked();
		CheckButtonAutoValue = CheckButtonAuto:GetChecked();
		CheckButtonDNDValue = CheckButtonDND:GetChecked();
		CheckButtonFilterValue = CheckButtonFilter:GetChecked();
		EditBoxReplaceNameValue = EditBoxReplaceName:GetText();
		EditBoxRateMinValue = EditBoxRateMin:GetText();
		EditBoxRateMaxValue = EditBoxRateMax:GetText();
		EditBoxPitchMinValue = EditBoxPitchMin:GetText();
		EditBoxPitchMaxValue = EditBoxPitchMax:GetText();
		local len = table.getn(defaultSettings);
		for i = 1, len do
			local row = defaultSettings[i];
			local editBoxPrefix = row["EditBoxPrefix"];
			local voices = row["Voices"];
			local voicesLen = table.getn(voices);
			AllSavedValues[i] = { };
			AllSavedValues[i]["Voices"] = { };
			for v = 1, voicesLen do
				local name = editBoxPrefix ..(v - 1);
				AllSavedValues[i]["Voices"][v] = { };
				AllSavedValues[i]["Voices"][v][1] = true;
				AllSavedValues[i]["Voices"][v][2] = 100;
				AllSavedValues[i]["Voices"][v][3] = GetFrame(name):GetText();
			end
		end
		CharacterFirstLoginValue = 1;
	end

	-- FUNCTION MESSAGE STOP

	local function sendChatMessageStop()
		if framesClosed == 1 then
			-- Disable Do Not Disturb
			if CheckButtonDND:GetChecked() == 1 then
				if UnitIsDND("player") == 1 then
					SendChatMessage("", "DND");
				end
			end
			-- Send messageStop
			SendChatMessage(messageStop, "WHISPER", "Common", unitName);
			EditBoxQuest:SetText(messageStop);
			EditBoxQuest:HighlightText();
			EditBoxMini:SetText(messageStop);
			EditBoxMini:HighlightText();
		end
		framesClosed = 0;
	end

	-- FUNCTION ENABLE or DISABLE OPTIONS

	local function showFrames()
		FrameOptions:Show();
		ButtonOptions:SetText("Minimize");
		FrameMini:SetMovable(true);
		FrameMini.texture:SetTexture(0, 0, 0, 0.8);
		FrameScroll:SetMovable(true);
		FrameScroll:SetResizable(true);
		FrameScroll:EnableMouse(true);
		FrameScroll.texture:SetTexture(0, 0, 0, 0.8);
		FrameScroll:Show();
		TextScroll:Show();
		ResizeButton:Show();
	end

	local function hideFrames()
		FrameOptions:Hide();
		FrameMini:SetMovable(false);
		FrameMini.texture:SetTexture(0, 0, 0, 0);
		ButtonOptions:SetText("Options");
		FrameScroll:SetMovable(false);
		FrameScroll:SetResizable(false);
		FrameScroll:EnableMouse(false);
		FrameScroll.texture:SetTexture(0, 0, 0, 0);
		if CheckButtonEnable:GetChecked() ~= 1 then
			FrameScroll:Hide();
		end
		TextScroll:Hide();
		ResizeButton:Hide();
	end

	local function functionOptions()
		if FrameOptions:IsShown() then
			saveValues();
			hideFrames();
		else
			showFrames();
		end
	end
	ButtonOptions:SetScript("OnClick", functionOptions);
	FrameOptions:SetScript("OnHide", hideFrames);
	FrameOptions:SetScript("OnShow", showFrames);

	-- FUNCTION ENABLE or DISABLE TTS

	local function functionClose()
		hideFrames();
		CloseQuest();
		CloseGossip();
		sendChatMessageStop();
	end

	-- FUNCTION ON ESCAPE
	local len = table.getn(defaultSettings);
	for i = 1, len do
		local row = defaultSettings[i];
		local editBoxPrefix = row["EditBoxPrefix"];
		local voices = row["Voices"];
		local voicesLen = table.getn(voices);
		for v = 1, voicesLen do
			local name = editBoxPrefix ..(v - 1);
			GetFrame(name):SetScript("OnEscapePressed", functionClose);
		end
	end
	EditBoxRateMin:SetScript("OnEscapePressed", functionClose);
	EditBoxRateMax:SetScript("OnEscapePressed", functionClose);
	EditBoxPitchMin:SetScript("OnEscapePressed", functionClose);
	EditBoxPitchMax:SetScript("OnEscapePressed", functionClose);
	EditBoxMini:SetScript("OnEscapePressed", functionClose);
	EditBoxQuest:SetScript("OnEscapePressed", functionClose);
	EditBoxReplaceName:SetScript("OnEscapePressed", functionClose);

	-- FUNCTION CLEAR

	local function functionReset()
		greeting = "";
		gossip = "";
		quest = "";
		objective = "";
		progress = "";
		reward = "";
		output = ""
		EditBoxQuest:SetText("");
		EditBoxMini:SetText("");
	end

	-- FUNCTION SET COLOR
	local function setColor(parameter, frameName, color)
		local frame = GetFrame(frameName);
		if color == 2 then
			frame:SetTextColor(0.0, 1.0, 0.0, 1.0);
			-- green (2)
		else
			frame:SetTextColor(1.0, 1.0, 1.0, 1.0);
			-- white (1)
		end
		if parameter == "voice" then
			voiceName = frame:GetText();
			voiceFrameNameDisable = frameName;
		end
	end

	-- FUNCTION ENABLE / DISABLE TTS

	local function functionEnable()
		if CheckButtonEnable:GetChecked() == 1 then
			CheckButtonFilter:SetChecked(1);
			CheckButtonAuto:SetChecked(1);
			CheckButtonDND:SetChecked(1);
			functionClose();
			functionReset();
		else
			CheckButtonAuto:SetChecked(nil);
			-- Disable Do Not Disturb
			if CheckButtonDND:GetChecked() == 1 then
				if UnitIsDND("player") == 1 then
					SendChatMessage("", "DND");
				end
			end
			CheckButtonDND:SetChecked(nil);
			setColor("voice", voiceFrameNameDisable, 1);
			-- green (1)
			-- setColor("pitch", pitchFrameNameDisable, 1); -- green (1)			
			sendChatMessageStop();
			functionReset();
		end
	end
	CheckButtonEnable:SetScript("OnClick", functionEnable);

	-- FUNCTION ENABLE / DISABLE AUTO SPEECH

	local function functionAuto()
		if CheckButtonAuto:GetChecked() == 1 then
			if CheckButtonEnable:GetChecked() ~= 1 then
				CheckButtonEnable:SetChecked(1);
				functionClose();
				functionReset();
			end
		end
	end
	CheckButtonAuto:SetScript("OnClick", functionAuto);

	-- FUNCTION ENABLE / DISABLE AUTO DO NOT DISTURB

	local function functionDND()
		if CheckButtonDND:GetChecked() == 1 then
			if UnitIsDND("player") == nil then
				if framesClosed == 1 then
					SendChatMessage("<" .. unitName .. ">: " .. textDoNotDisturb, "DND");
				end
			end
		else
			if UnitIsDND("player") == 1 then
				SendChatMessage("", "DND");
			end
		end
	end
	CheckButtonDND:SetScript("OnClick", functionDND);

	-- SET VALUE IF FRAMES ARE VISIBLE (1) OR NOT (0)

	visibleGossip = GossipFrame:IsShown();
	visibleQuest = QuestFrame:IsShown();
	if visibleGossip == 0 or visibleGossip == "" or visibleGossip == nil then
		visibleGossip = 0;
	else
		visibleGossip = 1;
	end
	if visibleQuest == 0 or visibleQuest == "" or visibleQuest == nil then
		visibleQuest = 0;
	else
		visibleQuest = 1;
	end
	visibleFrames = visibleGossip + visibleQuest;

	-- FRAMES HIDE

	if event == "QUEST_ACCEPTED" or event == "QUEST_FINISHED" or event == "GOSSIP_CLOSED" then

		if visibleFrames == 0 then
			FrameMini:Hide();
			FrameScroll:Hide();
			hideFrames();
			functionReset();
			if CheckButtonEnable:GetChecked() == 1 then
				sendChatMessageStop();
			end
		end

	end

	-- FRAMES SHOW

	if event == "QUEST_GREETING" or event == "GOSSIP_SHOW" or event == "QUEST_DETAIL" or event == "QUEST_PROGRESS" or event == "QUEST_COMPLETE" then

		FrameMini:Show();

		if CheckButtonEnable:GetChecked() == 1 then

			FrameScroll:Show();
			functionReset();

			-- FUNCTON SET VOICE, PITCH AND RATE

			local function setVoice()
				-- unitGUID = UnitGUID("target");
				-- if unitGUID == nil then unitGUID = "12345678901234567890" end;
				-- targetGUIDNumber = tonumber((unitGUID):sub(-12, -9), 16);

				-- targetClass = UnitClass("target");
				-- if targetClass == nil then targetClass = "nil" end;

				-- targetClassification = UnitClassification("target"); -- worldboss, rareelite, elite, rare, normal, trivial or minus
				-- if targetClassification == nil then targetClassification = "nil" end;

				targetName = GetUnitName("target");
				if targetName == nil then targetName = "nil" end;

				-- targetFaction = UnitFactionGroup("target"); -- Horde, Alliance, Neutral
				-- if targetFaction == nil then targetFaction = "nil" end;

				targetCreature = UnitCreatureType("target");
				-- Beast, Dragonkin, Demon, Elemental, Giant, Undead, Humanoid, Critter, Mechanical, Not specified, Totem, Non-combat Pet, Gas Cloud							
				if targetCreature == nil then targetCreature = "Default" end;

				targetSex = UnitSex("target");
				if targetSex == nil then targetSex = 1 end;

				if targetSex == 3 then
					sex = "Female";
					sexFrame = "EditBoxF";
				elseif targetSex == 2 then
					sex = "Male";
					sexFrame = "EditBoxM";
				else
					sex = "Unknown";
					sexFrame = "EditBoxU";
				end

				targetInfo = targetName .. sex;

				-- SET VOICE

				speechVoiceMin = 0;
				speechVoiceMax = 9;
				speechVoice = GetNumber(speechVoiceMin, speechVoiceMax, "voice", targetInfo);
				-- SET VOICE
				voiceFrameNameNew = sexFrame .. speechVoice;
				-- Voice frame name and number	

				-- SET PITCH

				speechPitchMin = EditBoxPitchMin:GetText();
				if (speechPitchMin == "") or speechPitchMin == nil then
					speechPitchMin = PitchMin;
					EditBoxPitchMin:SetText(PitchMin);
				end
				speechPitchMin = tonumber(speechPitchMin);

				speechPitchMax = EditBoxPitchMax:GetText();
				if (speechPitchMax == "") or speechPitchMax == nil then
					speechPitchMax = PitchMax;
					EditBoxPitchMax:SetText(PitchMax);
				end
				speechPitchMax = tonumber(speechPitchMax);

				speechPitch = GetNumber(speechPitchMin, speechPitchMax, "pitch", targetInfo);
				-- SET PITCH

				speechPitchL = string.sub(speechPitch, 1, 1);
				if speechPitchL == "-" then
					pitchChange = 10;
				else
					pitchChange = -10;
				end
				pitchComment = speechPitch + pitchChange;

				-- SET RATE

				speechRateMin = EditBoxRateMin:GetText();
				if (speechRateMin == "") or speechRateMin == nil then
					speechRateMin = RateMin;
					EditBoxRateMin:SetText(RateMin);
				end
				speechRateMin = tonumber(speechRateMin);

				speechRateMax = EditBoxRateMax:GetText();
				if (speechRateMax == "") or speechRateMax == nil then
					speechRateMax = RateMax;
					EditBoxRateMax:SetText(RateMax);
				end
				speechRateMax = tonumber(speechRateMax);

				speechRate = GetNumber(speechRateMin, speechRateMax, "rate", targetInfo);
				-- SET RATE

			end
			setVoice();

			-- RESET / SET VOICE AND PITCH COLOR

			local function resetSetColor()
				if voiceFrameNameOld == nil then
					voiceFrameNameOld = voiceFrameNameNew;
				end
				setColor("voice", voiceFrameNameOld, 1);
				-- white
				setColor("voice", voiceFrameNameNew, 2);
				-- green
				voiceFrameNameOld = voiceFrameNameNew;
			end
			resetSetColor();

			-- GET QUEST TEXT BY EVENT

			local function outputFromEvent()
				if event == "QUEST_GREETING" then
					output = GetGreetingText();
				end
				if event == "GOSSIP_SHOW" then
					output = GetGossipText();
				end
				if event == "QUEST_DETAIL" then
					output = GetQuestText() .. " Your objective is to " .. GetObjectiveText();
				end
				if event == "QUEST_PROGRESS" then
					output = GetProgressText();
				end
				if event == "QUEST_COMPLETE" then
					output = GetRewardText();
				end

				-- REPLACE NAME

				EditBoxReplaceNameTo = EditBoxReplaceName:GetText();
				if string.len(EditBoxReplaceNameTo) > 0 and EditBoxReplaceNameTo ~= unitName then
					output = string.gsub(output, unitName, EditBoxReplaceNameTo);
				end

				-- FORMAT AND REPLACE TEXT

				output = string.gsub(output, "\r", " ");
				output = string.gsub(output, "\n", " ");
				output = string.gsub(output, "[%.]+", ". ");
				output = string.gsub(output, "<", " &lt;pitch absmiddle=\"" .. pitchComment .. "\"&gt;");
				output = string.gsub(output, ">", "&lt;/pitch&gt; ");
				output = string.gsub(output, "[ ]+", " ");

				outputMessage = output;

			end
			outputFromEvent();

			-- FUNCTION : FORMAT AND SEND WHISPERS

			local function sendPart(part, command)
				-- ====================================================
				-- Add voices to the list: Name, Weight.
				local voices = { };
				voices[1] = { "IVONA Brian", 100 };
				voices[2] = { "Microsoft Hazel Desktop", 40 };
				local npcInfo = "Quest Giver Name, race, gender";
				local newVoceName = PickVoice(voices, npcInfo);
				local newPitch = GetNumber(-10, 10, "pitch", npcInfo);
				local newRate = GetNumber(1, 2, "rate", npcInfo);
				local gender = "Neutral";
				-- Male, Female,
				-- ====================================================

				chatMessageS = "<voice name=\"" .. voiceName .. "\" gender=\"" .. sex .. "\" pitch=\"" .. speechPitch .. "\" rate=\"" .. speechRate .. "\" effect=\"" .. targetCreature .. "\" command=\"" .. command .. "\"><part>";
				chatMessageE = "</part></voice>";
				local chatMessage = chatMessageS .. part .. chatMessageE;
				SendChatMessage(chatMessage, "WHISPER", "Common", unitName);
			end

			local function messageSpeak(sender)
				if (sender == "Scroll") or(sender == "Auto" and CheckButtonAuto:GetChecked() == 1) then

					-- Disable Do Not Disturb
					if CheckButtonDND:GetChecked() == 1 then
						if UnitIsDND("player") == 1 then
							SendChatMessage("", "DND");
						end
					end

					framesClosed = 1;
					local size = 140;
					local startIndex = 1;
					local endIndex = 1;
					local part = "";
					while true do
						local command = "";
						local index = string.find(outputMessage, " ", endIndex);
						-- print(index);
						-- if nothing found then...
						if index == nil then
							part = string.sub(outputMessage, startIndex);
							sendPart(part, "play");
							-- print("[" .. startIndex .. "] '" .. part .. "'");
							break;
						elseif (index - startIndex) > size then
							-- if space is out of size then...
							part = string.sub(outputMessage, startIndex, endIndex - 1);
							sendPart(part, "add");
							-- print("[" .. startIndex .. "-" .. (endIndex - 1) .. "] '" .. part .. "'");
							startIndex = endIndex;
						end
						-- look for next space.
						endIndex = index + 1;
					end

					-- Enable Do Not Disturb
					if CheckButtonDND:GetChecked() == 1 then
						-- if UnitIsDND("player") == nil then
						SendChatMessage("<" .. unitName .. ">: " .. textDoNotDisturb, "DND");
						-- end
					end

					-- FILL EDITBOXES		
					outputEditBox = chatMessageS .. "\n|cffffffff" .. outputMessage .. "|r\n" .. chatMessageE;
					-- "<" .. event .. " />" ..
					EditBoxQuest:SetText(outputEditBox);
					EditBoxQuest:HighlightText();
					EditBoxMini:SetText(outputEditBox);
					EditBoxMini:HighlightText();

				end
			end
			messageSpeak("Auto");

			-- FUNCTION ON SCROLL

			local function onMouseWheel(self, delta)
				functionReset();
				if CheckButtonEnable:GetChecked() == 1 then

					-- Send Message
					if delta == 1 then
						setVoice();
						resetSetColor();
						outputFromEvent();
						messageSpeak("Scroll");
					else
						sendChatMessageStop();
					end

				end
			end
			FrameScroll:SetScript("OnMouseWheel", onMouseWheel);

		end
		-- if Disable TTS end

	end
	-- if QUEST EVENTS end

	-- SAVING VALUES ON PLAYER_LOGOUT

	if event == "PLAYER_LOGOUT" then
		saveValues();
		FrameMini:SetMovable(true);
		FrameMini:SetUserPlaced(true);
		FrameOptions:SetMovable(true);
		FrameOptions:SetUserPlaced(true);
		FrameScroll:SetMovable(true);
		FrameScroll:SetResizable(true);
		FrameScroll:SetUserPlaced(true);
	end

end
FrameOptions:SetScript("OnEvent", eventFunction);

